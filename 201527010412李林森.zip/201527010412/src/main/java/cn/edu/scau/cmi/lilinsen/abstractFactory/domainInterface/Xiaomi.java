package cn.edu.scau.cmi.lilinsen.abstractFactory.domainInterface;

public interface Xiaomi {
	String companyName = "Xiaomi"; 
}
