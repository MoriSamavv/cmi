package cn.edu.scau.cmi.lilinsen.adapter;

public class AdapterOfObject implements Target{
	Adaptee adaptee = new Adaptee();
	
	@Override
	public void sayHello() {
		// TODO Auto-generated method stub
		this.adaptee.sayHello();
	}

	@Override
	public void sayMe() {
		// TODO Auto-generated method stub
		System.out.println("I am AdapterOfObject");
	}

}
