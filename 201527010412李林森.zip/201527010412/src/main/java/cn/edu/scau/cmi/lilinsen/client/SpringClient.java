package cn.edu.scau.cmi.lilinsen.client;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import cn.edu.scau.cmi.lilinsen.spring.domain.Student;
import cn.edu.scau.cmi.lilinsen.spring.domain.Teacher;

public class SpringClient {
	public static void main(String args[]) {
		ApplicationContext ac=new ClassPathXmlApplicationContext("applicationContext.xml");
		Student student=(Student) ac.getBean("lilinsen");
		System.out.println(student.getId()+"  "+student.getName());
		
		Teacher teacher=(Teacher) ac.getBean("liangzaoqing");
		System.out.println(teacher.getId()+"  "+teacher.getName());
	}

}
