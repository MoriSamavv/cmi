package cn.edu.scau.cmi.lilinsen.abstractFactory.domain;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Awatch;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainInterface.Apple;

public class Applewatch extends Awatch implements Apple{

	@Override
	public void whatCompany() {
		// TODO Auto-generated method stub
		whatType();
		System.out.println(" from "+companyName);
	}

}
