package cn.edu.scau.cmi.lilinsen.factory;

public interface Factory {

}
