package cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass;

public abstract class Apad extends Basetype{
	
	public void whatType() {
		System.out.print("I am pad");
	};
	
	public abstract void whatCompany();
}
