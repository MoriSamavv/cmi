package cn.edu.scau.cmi.lilinsen.adapter;

public interface Target {
	void sayHello();
	void sayMe();
}
