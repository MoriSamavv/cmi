package cn.edu.scau.cmi.lilinsen.client;

import java.util.ArrayList;
import java.util.List;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.cfg.Configuration;

import cn.edu.scau.cmi.lilinsen.hibernate.dao.StudentDAO;
import cn.edu.scau.cmi.lilinsen.hibernate.domain.Student;

public class Hibernateclient {
	public static void main(String[] args){
		StudentDAO sd = new StudentDAO();
		List<Student> list = new ArrayList<Student>();
		Student student = new Student(555,"hhh");
		Student student2 = new Student(111,"rrr");
		
		System.out.println("����ǰ��");
		list = sd.findAll();
		for(Student s : list){
			System.out.println(s.getStuId()+" "+s.getStuName());
		}
		sd.save(student);
		System.out.println("���Ӻ�");
		list = sd.findAll();
		for(Student s : list){
			System.out.println(s.getStuId()+" "+s.getStuName());
		}
		System.out.println("-------------------------------------");
		
//		System.out.println("ɾ��ǰ��");
//		list = sd.findAll();
//		for(Student s : list){
//			System.out.println(s.getStuId()+" "+s.getStuName());
//		}
//		sd.delete(student);
//		System.out.println("ɾ����");
//		list = sd.findAll();
//		for(Student s : list){
//			System.out.println(s.getStuId()+" "+s.getStuName());
//		}
//		System.out.println("-------------------------------------");
		
		System.out.println("�޸�ǰ��");
		list = sd.findAll();
		for(Student s : list){
			System.out.println(s.getStuId()+" "+s.getStuName());
		}
		sd.merge(student2);
		System.out.println("�޸ĺ�");
		list = sd.findAll();
		for(Student s : list){
			System.out.println(s.getStuId()+" "+s.getStuName());
		}
		System.out.println("-------------------------------------");
		
		System.out.println("���ң�");
		System.out.println(sd.findById(111).getStuName());
		
	}
}
