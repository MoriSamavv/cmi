package cn.edu.scau.cmi.lilinsen.client;

import cn.edu.scau.cmi.lilinsen.singletonpattern.President;

public class Singletonclient {
	public static void main(String[] args) {
		President president1 = President.getInstance("ϰ��ƽ");
		President president2 = President.getInstance("ϰ��ƽ");
		if(president1==president2) {
			System.out.println("������һ����");
		}
		else {
			System.out.println("���ǲ�һ��");
		}
		System.out.println(president1);
		System.out.println(president2);
	}
}
