package cn.edu.scau.cmi.lilinsen.composite.safe;

public abstract class Organizations {
	public abstract void say();
}
