package cn.edu.scau.cmi.lilinsen.abstractFactory.factory;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Basetype;


public abstract class AbstractFactory {
	public static AbstractFactory getFactory(String name) {
		switch(name) {
		case "apple":return new AppleFactory();
		case "huawei":return new HuaweiFactory();
		case "xiaomi":return new XiaomiFactory();
		}
		return null;
	}
	public abstract Basetype createPad();
	public abstract Basetype createPhone();
	public abstract Basetype createWatch();
}
