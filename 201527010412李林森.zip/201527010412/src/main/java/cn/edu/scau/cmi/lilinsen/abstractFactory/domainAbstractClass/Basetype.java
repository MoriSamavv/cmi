package cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass;

public abstract class Basetype {
	public abstract void whatType();
}
