package cn.edu.scau.cmi.lilinsen.abstractFactory.factory;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Xiaomipad;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Xiaomiphone;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Xiaomiwatch;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Basetype;

public class XiaomiFactory extends AbstractFactory{

	@Override
	public Basetype createPad() {
		// TODO Auto-generated method stub
		return new Xiaomipad();
	}

	@Override
	public Basetype createPhone() {
		// TODO Auto-generated method stub
		return new Xiaomiphone();
	}

	@Override
	public Basetype createWatch() {
		// TODO Auto-generated method stub
		return new Xiaomiwatch();
	}

}
