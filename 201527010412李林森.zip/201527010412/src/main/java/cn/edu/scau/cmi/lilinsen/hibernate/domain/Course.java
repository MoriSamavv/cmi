package cn.edu.scau.cmi.lilinsen.hibernate.domain;

/**
 * Course entity. @author MyEclipse Persistence Tools
 */
public class Course extends AbstractCourse implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Course() {
	}

	/** full constructor */
	public Course(Integer couId, String couName) {
		super(couId, couName);
	}

}
