package cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass;

public abstract class Aphone extends Basetype{
	
	public void whatType() {
		System.out.print("I am phone");
	};

	public abstract void whatCompany();
}
