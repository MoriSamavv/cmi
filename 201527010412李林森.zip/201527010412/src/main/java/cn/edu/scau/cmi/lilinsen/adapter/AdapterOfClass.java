package cn.edu.scau.cmi.lilinsen.adapter;

public class AdapterOfClass extends Adaptee implements CusAdaptee{

	@Override
	public void sayMe() {
		// TODO Auto-generated method stub
		System.out.println("I am AdapterOfClass");
	}
}
