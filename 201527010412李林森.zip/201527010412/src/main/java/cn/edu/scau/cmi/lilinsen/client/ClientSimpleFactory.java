package cn.edu.scau.cmi.lilinsen.client;

import cn.edu.scau.cmi.lilinsen.domain.Person;
import cn.edu.scau.cmi.lilinsen.simpleFactory.PersonFactory;

public class ClientSimpleFactory {
	public static void main(String[] args) {
		Person student = PersonFactory.getPerson("student");
		student.speak();
	}
}
