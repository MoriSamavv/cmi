package cn.edu.scau.cmi.lilinsen.composite.transparent;


public class Person extends Organizations{
	
	private String name;
	public Person(String name) {
		this.name = name;
	}
	
	@Override
	public void say() {
		// TODO Auto-generated method stub
		System.out.println("I am "+name);
	}

	@Override
	public void add(Organizations person) {
		// TODO Auto-generated method stub
		System.out.println("报错警告！");
	}

	@Override
	public void remove(Organizations person) {
		// TODO Auto-generated method stub
		System.out.println("报错警告！");
	}

}
