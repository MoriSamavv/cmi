package cn.edu.scau.cmi.lilinsen.client;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Apad;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Basetype;
import cn.edu.scau.cmi.lilinsen.abstractFactory.factory.AbstractFactory;
import cn.edu.scau.cmi.lilinsen.abstractFactory.factory.AppleFactory;

public class ClientAbstractFactory {
	public static void main(String[] args) {
		AppleFactory factory = (AppleFactory)AbstractFactory.getFactory("apple");
		Apad pad = (Apad) factory.createPad();
		pad.whatCompany();
	}
}
