package cn.edu.scau.cmi.lilinsen.factory;

import cn.edu.scau.cmi.lilinsen.domain.Teacher;

public class TeacherFactory implements Factory{
	public static Teacher getTeacher() {
		return new Teacher();
	}
}
