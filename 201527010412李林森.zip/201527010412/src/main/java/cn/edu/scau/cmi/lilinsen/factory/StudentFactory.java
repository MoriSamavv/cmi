package cn.edu.scau.cmi.lilinsen.factory;

import cn.edu.scau.cmi.lilinsen.domain.Student;


public class StudentFactory implements Factory{
	public static Student getStudent() {
		return new Student();
	}
}
