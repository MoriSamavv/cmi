package cn.edu.scau.cmi.lilinsen.abstractFactory.domain;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Awatch;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainInterface.Huawei;

public class Huaweiwatch extends Awatch implements Huawei{

	@Override
	public void whatCompany() {
		// TODO Auto-generated method stub
		whatType();
		System.out.println(" from "+companyName);
	}

}
