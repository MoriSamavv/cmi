package cn.edu.scau.cmi.lilinsen.abstractFactory.factory;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Huaweipad;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Huaweiphone;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Huaweiwatch;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Basetype;

public class HuaweiFactory extends AbstractFactory{

	@Override
	public Basetype createPad() {
		// TODO Auto-generated method stub
		return new Huaweipad();
	}

	@Override
	public Basetype createPhone() {
		// TODO Auto-generated method stub
		return new Huaweiphone();
	}

	@Override
	public Basetype createWatch() {
		// TODO Auto-generated method stub
		return new Huaweiwatch();
	}

}
