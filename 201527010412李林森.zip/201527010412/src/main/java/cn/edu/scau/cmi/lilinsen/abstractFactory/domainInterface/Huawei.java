package cn.edu.scau.cmi.lilinsen.abstractFactory.domainInterface;

public interface Huawei {
	String companyName = "Huawei"; 
}
