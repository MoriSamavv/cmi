package cn.edu.scau.cmi.lilinsen.adapter;

public class Adaptee {
	public void sayHello() {
		System.out.println("Hello!");
	}
}
