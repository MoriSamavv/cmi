package cn.edu.scau.cmi.lilinsen.simpleFactory;

import cn.edu.scau.cmi.lilinsen.domain.Student;
import cn.edu.scau.cmi.lilinsen.domain.Teacher;
import cn.edu.scau.cmi.lilinsen.factory.Factory;
import cn.edu.scau.cmi.lilinsen.domain.Person;

public class PersonFactory implements Factory{
	public static Person getPerson(String s) {
		switch(s) {
		case "student":return new Student();
		case "teacher":return new Teacher();
		}
		return null;
	}
}
