package cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass;

public abstract class Awatch extends Basetype{
	public void whatType() {
		System.out.print("I am watch");
	};
	
	public abstract void whatCompany();
}
