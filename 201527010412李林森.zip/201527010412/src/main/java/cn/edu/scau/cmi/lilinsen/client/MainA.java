package cn.edu.scau.cmi.lilinsen.client;

import cn.edu.scau.cmi.lilinsen.domain.Student;

import cn.edu.scau.cmi.lilinsen.domain.Teacher;
import cn.edu.scau.cmi.lilinsen.factory.StudentFactory;
import cn.edu.scau.cmi.lilinsen.factory.TeacherFactory;

public class MainA {
	public static void main(String[] args) {
		Student student = StudentFactory.getStudent();
		student.speak();
		
		Teacher teacher = TeacherFactory.getTeacher();
		teacher.speak();
	}
}
