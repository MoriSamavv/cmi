package cn.edu.scau.cmi.lilinsen.domain;

public interface Person {
	public void speak();
}
