package cn.edu.scau.cmi.lilinsen.hibernate.domain;

/**
 * AbstractCourse entity provides the base persistence definition of the Course
 * entity. @author MyEclipse Persistence Tools
 */

public abstract class AbstractCourse implements java.io.Serializable {

	// Fields

	private Integer couId;
	private String couName;

	// Constructors

	/** default constructor */
	public AbstractCourse() {
	}

	/** full constructor */
	public AbstractCourse(Integer couId, String couName) {
		this.couId = couId;
		this.couName = couName;
	}

	// Property accessors

	public Integer getCouId() {
		return this.couId;
	}

	public void setCouId(Integer couId) {
		this.couId = couId;
	}

	public String getCouName() {
		return this.couName;
	}

	public void setCouName(String couName) {
		this.couName = couName;
	}

}