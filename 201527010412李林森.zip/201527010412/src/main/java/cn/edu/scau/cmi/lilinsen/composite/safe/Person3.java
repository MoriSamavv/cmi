package cn.edu.scau.cmi.lilinsen.composite.safe;

public class Person3 extends Organizations{

	@Override
	public void say() {
		// TODO Auto-generated method stub
		System.out.println("I am Person3");
	}

}
