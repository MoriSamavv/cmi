package cn.edu.scau.cmi.lilinsen.singletonpattern;

public class President {
	private static President instance;
	private String name;
	private President(String name) {
		this.name = name;
	}
	public static President getInstance(String name) {
		if(instance==null && name!=null && !name.equals(null)) {
			instance = new President(name);
		}
		return instance;
	}
	
}
