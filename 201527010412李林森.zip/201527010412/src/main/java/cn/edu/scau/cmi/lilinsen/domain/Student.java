package cn.edu.scau.cmi.lilinsen.domain;

public class Student implements Person{
	public Student() {
	}
	public void speak() {
		System.out.println("i am student");
	}
	
	public void getName() {
		System.out.println("student");
	}
}
