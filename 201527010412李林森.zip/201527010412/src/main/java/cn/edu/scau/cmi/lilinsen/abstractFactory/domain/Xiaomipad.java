package cn.edu.scau.cmi.lilinsen.abstractFactory.domain;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Apad;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainInterface.Xiaomi;

public class Xiaomipad extends Apad implements Xiaomi{

	@Override
	public void whatCompany() {
		// TODO Auto-generated method stub
		whatType();
		System.out.println(" from "+companyName);
	}

}
