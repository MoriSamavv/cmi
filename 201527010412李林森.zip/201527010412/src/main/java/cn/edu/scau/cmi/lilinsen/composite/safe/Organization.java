package cn.edu.scau.cmi.lilinsen.composite.safe;

import java.util.ArrayList;

public class Organization extends Organizations{
	private ArrayList<Organizations> list;
	
	public Organization() {
		list = new ArrayList<Organizations>();
	}
	
	public void add(Organizations person) {
		if(person != null) {
			list.add(person);
		}
	}
	
	public void remove(Organizations person) {
		if(person != null) {
			list.remove(person);
		}
	}
	
	public void say() {
		int len = list.size();
		for(Organizations person:list) {
			person.say();
		}
	}
}
