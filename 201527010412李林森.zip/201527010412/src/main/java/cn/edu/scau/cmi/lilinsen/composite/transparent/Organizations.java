package cn.edu.scau.cmi.lilinsen.composite.transparent;

public abstract class Organizations {
	public abstract void say();
	public abstract void add(Organizations person);
	public abstract void remove(Organizations person);
}
