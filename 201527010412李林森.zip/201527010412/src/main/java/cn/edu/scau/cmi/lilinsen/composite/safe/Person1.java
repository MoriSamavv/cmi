package cn.edu.scau.cmi.lilinsen.composite.safe;

public class Person1 extends Organizations{
	public void say() {
		System.out.println("I am Person1");
	}
}
