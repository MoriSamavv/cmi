package cn.edu.scau.cmi.lilinsen.client;

import cn.edu.scau.cmi.lilinsen.adapter.AdapterOfClass;
import cn.edu.scau.cmi.lilinsen.adapter.AdapterOfObject;
import cn.edu.scau.cmi.lilinsen.adapter.CusAdaptee;
import cn.edu.scau.cmi.lilinsen.adapter.Target;

public class AdapterClient {
	public static void main(String[] args) {
		CusAdaptee cus = new AdapterOfClass();
		cus.sayHello();
		cus.sayMe();
		
		
		Target target = new AdapterOfObject();
		target.sayHello();
		target.sayMe();
	}
}
