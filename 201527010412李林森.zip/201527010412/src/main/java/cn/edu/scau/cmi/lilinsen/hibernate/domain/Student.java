package cn.edu.scau.cmi.lilinsen.hibernate.domain;

/**
 * Student entity. @author MyEclipse Persistence Tools
 */
public class Student extends AbstractStudent implements java.io.Serializable {

	// Constructors

	/** default constructor */
	public Student() {
	}

	/** full constructor */
	public Student(Integer stuId, String stuName) {
		super(stuId, stuName);
	}

}
