package cn.edu.scau.cmi.lilinsen.client;


import cn.edu.scau.cmi.lilinsen.composite.safe.Organization;
import cn.edu.scau.cmi.lilinsen.composite.safe.Organizations;
import cn.edu.scau.cmi.lilinsen.composite.safe.Person1;
import cn.edu.scau.cmi.lilinsen.composite.safe.Person2;
import cn.edu.scau.cmi.lilinsen.composite.safe.Person3;

public class SafecompositeClient {
	public static void main(String[] args) {
		Organizations p1 = new Person1();
		Organizations p2 = new Person2();
		Organizations p3 = new Person3();
		Organizations organization = new Organization();
		((Person1)p1).say();
		((Organization)organization).add(p2);
		((Organization)organization).add(p3);
		((Organization)organization).say();
	}
}
