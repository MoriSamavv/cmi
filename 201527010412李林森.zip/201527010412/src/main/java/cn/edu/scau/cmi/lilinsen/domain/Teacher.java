package cn.edu.scau.cmi.lilinsen.domain;

public class Teacher implements Person{
	public Teacher() {	
	}
	public void speak() {
		System.out.println("i am teacher");
	}
	public void getName() {
		System.out.println("teacher");
	}
}
