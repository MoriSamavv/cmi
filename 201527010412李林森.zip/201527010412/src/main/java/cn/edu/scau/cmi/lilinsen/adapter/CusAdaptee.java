package cn.edu.scau.cmi.lilinsen.adapter;

public interface CusAdaptee {
	void sayHello();
	void sayMe();
}
