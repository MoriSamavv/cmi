package cn.edu.scau.cmi.lilinsen.client;


import cn.edu.scau.cmi.lilinsen.composite.transparent.Organization;
import cn.edu.scau.cmi.lilinsen.composite.transparent.Organizations;
import cn.edu.scau.cmi.lilinsen.composite.transparent.Person;

public class TransparentcompositeClient {
	public static void main(String[] args) {
		Organizations p1 = new Person("Person1");
		Organizations p2 = new Person("Person2");
		Organizations p3 = new Person("Person3");
		p1.say();
		p1.add(p2);
		Organizations organization = new Organization();
		organization.add(p2);
		organization.add(p3);
		organization.say();
	}
}
