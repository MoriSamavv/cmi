package cn.edu.scau.cmi.lilinsen.abstractFactory.factory;

import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Applepad;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Applephone;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domain.Applewatch;
import cn.edu.scau.cmi.lilinsen.abstractFactory.domainAbstractClass.Basetype;

public class AppleFactory extends AbstractFactory{

	@Override
	public Basetype createPad() {
		// TODO Auto-generated method stub
		return new Applepad();
	}

	@Override
	public Basetype createPhone() {
		// TODO Auto-generated method stub
		return new Applephone();
	}

	@Override
	public Basetype createWatch() {
		// TODO Auto-generated method stub
		return new Applewatch();
	}


}
